# %%
# AutoSteer + EgoLanes Visualization (all lanes, self-contained)
import sys
import cv2
import json
import numpy as np
from PIL import Image
from argparse import ArgumentParser
from datetime import datetime, timedelta

sys.path.append('../..')
from Models.inference.auto_steer_infer import AutoSpeedNetworkInfer
from inference.ego_lanes_infer import EgoLanesNetworkInfer


def rotate_wheel(wheel_img, angle_deg):
    h, w = wheel_img.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle_deg, 1.0)
    return cv2.warpAffine(
        wheel_img, M, (w, h),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0, 0)
    )


def overlay_on_top(base_img, rotated_wheel_img, frame_time, steering_angle, rotated_gt_wheel_img=None):
    H, W = base_img.shape[:2]
    oh, ow = rotated_wheel_img.shape[:2]
    x = W - ow - 60
    y = 20

    image = base_img.copy()

    def alpha_blend(dst, src, x, y):
        alpha = src[:, :, 3] / 255.0
        for c in range(3):
            dst[y:y+src.shape[0], x:x+src.shape[1], c] = (
                src[:, :, c] * alpha +
                dst[y:y+src.shape[0], x:x+src.shape[1], c] * (1 - alpha)
            )

    alpha_blend(image, rotated_wheel_img, x, y)

    if rotated_gt_wheel_img is not None:
        alpha_blend(image, rotated_gt_wheel_img, x - 148, y)

    cv2.putText(image, frame_time, (x - 60, y + oh + 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    cv2.putText(image, f"{steering_angle:.2f} deg", (x - 60, y + oh + 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    return image


def load_ground_truth(gt_file_path):
    with open(gt_file_path, 'r') as f:
        return json.load(f)


def overlay_egolanes(frame, lane_mask, threshold=0.3):
    """
    Overlay all EgoLanes on a frame.
    - frame: HxWx3 BGR
    - lane_mask: (num_lanes, H, W) or HxW float array
    - threshold: probability cutoff to consider pixel as lane
    """
    overlay = frame.copy()
    H, W = frame.shape[:2]

    if lane_mask.ndim == 3:  # multiple lanes
        num_lanes = lane_mask.shape[0]
        # Resize each lane mask to match frame size
        resized_masks = []
        for i in range(num_lanes):
            lm_resized = cv2.resize(lane_mask[i], (W, H), interpolation=cv2.INTER_NEAREST)
            resized_masks.append(lm_resized)
        for i, lm in enumerate(resized_masks):
            mask = (lm >= threshold).astype(np.uint8)
            # Colors for up to 4 lanes: left lanes red shades, right lanes blue shades
            colors = [(255, 0, 255), (255, 0, 0), (0, 255, 0), (255, 0, 255)]
            color = colors[i % len(colors)]
            overlay[mask > 0] = color
    else:  # single lane mask
        lm_resized = cv2.resize(lane_mask, (W, H), interpolation=cv2.INTER_NEAREST)
        mask = (lm_resized >= threshold).astype(np.uint8)
        overlay[mask > 0] = (0, 255, 0)

    return cv2.addWeighted(frame, 1.0, overlay, 0.5, 0)


def main():
    parser = ArgumentParser()
    parser.add_argument("-e", "--egolanes_checkpoint_path", required=True)
    parser.add_argument("-a", "--autosteer_checkpoint_path", required=True)
    parser.add_argument("-i", "--video_filepath", required=True)
    parser.add_argument("-o", "--output_file", required=True)
    parser.add_argument("-v", "--vis", action='store_true', default=False)
    parser.add_argument("-g", "--ground_truth")
    args = parser.parse_args()

    # -------------------------
    # Load models
    # -------------------------
    autosteer_model = AutoSpeedNetworkInfer(
        egolanes_checkpoint_path=args.egolanes_checkpoint_path,
        autosteer_checkpoint_path=args.autosteer_checkpoint_path
    )
    egolanes_model = EgoLanesNetworkInfer(args.egolanes_checkpoint_path)
    print("Models loaded")

    # -------------------------
    # Video setup
    # -------------------------
    cap = cv2.VideoCapture(args.video_filepath)
    fps = cap.get(cv2.CAP_PROP_FPS)

    writer = cv2.VideoWriter(
        args.output_file + ".avi",
        cv2.VideoWriter_fourcc(*"MJPG"),
        fps,
        (1280, 720)
    )

    wheel = cv2.resize(
        cv2.imread("/home/aiexnvidia24/autoware.privately-owned-vehicles/Media/wheel.png", cv2.IMREAD_UNCHANGED),
        None, fx=0.8, fy=0.8
    )
    gt_wheel = cv2.resize(
        cv2.imread("/home/aiexnvidia24/autoware.privately-owned-vehicles/Media/wheel_green.png", cv2.IMREAD_UNCHANGED),
        None, fx=0.8, fy=0.8
    )

    gt = load_ground_truth(args.ground_truth) if args.ground_truth else None
    start_datetime = datetime.now()
    frame_idx = 0

    # -------------------------
    # Process video frames
    # -------------------------
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Prepare input for models
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb).resize((640, 320))

        # -------------------------
        # Inference
        # -------------------------
        steering_angle = autosteer_model.inference(pil)
        lane_mask = egolanes_model.inference(np.array(pil))

        # -------------------------
        # Overlay EgoLanes (all lanes)
        # -------------------------
        frame = cv2.resize(frame, (1280, 720))
        frame = overlay_egolanes(frame, lane_mask, threshold=0.3)

        # -------------------------
        # Overlay steering wheels
        # -------------------------
        rotated_wheel = rotate_wheel(wheel, steering_angle)
        rotated_gt = None
        if gt:
            gt_angle = gt["frames"][frame_idx]["steering_angle_corrected"]
            rotated_gt = rotate_wheel(gt_wheel, gt_angle)

        timestamp = (start_datetime + timedelta(seconds=frame_idx / fps)).strftime("%m/%d/%Y %H:%M:%S")
        frame = overlay_on_top(frame, rotated_wheel, timestamp, steering_angle, rotated_gt)

        # -------------------------
        # Display & write
        # -------------------------
        if args.vis:
            cv2.imshow("AutoSteer + EgoLanes", frame)
            cv2.waitKey(1)

        writer.write(frame)
        frame_idx += 1

    cap.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"Completed. Output saved to {args.output_file}.avi")


if __name__ == "__main__":
    main()
# %%

