#%%
import cv2
import sys
import os
import time
import numpy as np
from PIL import Image
from argparse import ArgumentParser
import torch

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from inference.scene_seg_infer import SceneSegNetworkInfer


def find_freespace_edge(binary_mask):
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        return max(contours, key=lambda x: cv2.contourArea(x))
    return None


def make_visualization_freespace(prediction, rgb_small):
    colour_mask = rgb_small.copy()
    mask = (prediction == 2)
    h, w = prediction.shape
    binary_mask = np.zeros((h, w), dtype=np.uint8)
    binary_mask[mask] = 255
    edge = find_freespace_edge(binary_mask)
    if edge is not None and edge.size > 0:
        cv2.fillPoly(colour_mask, pts=[edge], color=(28, 255, 145))
    return cv2.cvtColor(colour_mask, cv2.COLOR_RGB2BGR)


def make_visualization(prediction):
    h, w = prediction.shape
    vis = np.zeros((h, w, 3), dtype=np.uint8)
    vis[:, :, 0] = 255
    vis[:, :, 1] = 93
    vis[:, :, 2] = 61
    fg = (prediction == 1)
    vis[fg] = (145, 28, 255)
    return vis


def main():
    parser = ArgumentParser()
    parser.add_argument("-p", "--model_checkpoint_path", required=True)
    parser.add_argument("-i", "--video_filepath", required=True)
    parser.add_argument("-s", "--show_scale", type=float, default=1.0)
    parser.add_argument("--skip_frames", type=int, default=0)
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    model = SceneSegNetworkInfer(checkpoint_path=os.path.expanduser(args.model_checkpoint_path))
    print("SceneSeg Model Loaded")

    cap = cv2.VideoCapture(os.path.expanduser(args.video_filepath))
    if not cap.isOpened():
        print("Error opening video file")
        return

    alpha = 0.5
    frame_count = 0
    total_frames = 0
    prev_time = time.time()
    print("Processing started")

    while True:
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        total_frames += 1
        if args.skip_frames > 0 and total_frames % (args.skip_frames + 1) != 0:
            continue

        # Resize to model input
        frame_small = cv2.resize(frame, (640, 320), interpolation=cv2.INTER_LINEAR)
        rgb_small = cv2.cvtColor(frame_small, cv2.COLOR_BGR2RGB)

        # Use PIL for inference
        image_pil = Image.fromarray(rgb_small)

        # Run inference (PIL-based, GPU if model supports it)
        prediction = model.inference(image_pil)
        prediction = np.squeeze(prediction)
        if prediction.dtype != np.integer:
            prediction = (prediction + 0.5).astype(np.int32)

        # Create visualizations
        vis_obj = make_visualization(prediction)  # RGB
        vis_obj_freespace = make_visualization_freespace(prediction, rgb_small)  # BGR
        vis_obj_bgr = cv2.cvtColor(vis_obj, cv2.COLOR_RGB2BGR)

        # Blend overlays
        blended_obj = cv2.addWeighted(vis_obj_bgr, alpha, frame_small, 1 - alpha, 0)
        blended_free = cv2.addWeighted(vis_obj_freespace, alpha, frame_small, 1 - alpha, 0)

        # Optional display scaling
        if args.show_scale != 1.0:
            w = int(blended_obj.shape[1] * args.show_scale)
            h = int(blended_obj.shape[0] * args.show_scale)
            disp_obj = cv2.resize(blended_obj, (w, h), interpolation=cv2.INTER_LINEAR)
            disp_free = cv2.resize(blended_free, (w, h), interpolation=cv2.INTER_LINEAR)
        else:
            disp_obj = blended_obj
            disp_free = blended_free

        # FPS monitor
        frame_count += 1
        t = time.time()
        if t - prev_time >= 1.0:
            print(f"FPS: {frame_count}")
            frame_count = 0
            prev_time = t

        # Show
        cv2.imshow("Objects", disp_obj)
        cv2.imshow("Freespace", disp_free)

        if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q")):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("Stopped")


if __name__ == "__main__":
    main()

