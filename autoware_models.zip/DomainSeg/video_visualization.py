#%%
import cv2
import sys
import os
import numpy as np
from PIL import Image
from argparse import ArgumentParser

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from inference.domain_seg_infer import DomainSegNetworkInfer

def make_visualization(prediction):
    shape = prediction.shape
    row, col = shape[0], shape[1]
    vis_predict_object = np.zeros((row, col, 3), dtype="uint8")

    # Assign background colour
    vis_predict_object[:, :, 0] = 255
    vis_predict_object[:, :, 1] = 93
    vis_predict_object[:, :, 2] = 61

    # Get foreground object labels
    foreground_labels = np.where(prediction == 1.0)

    # Assign foreground objects colour
    vis_predict_object[foreground_labels[0], foreground_labels[1], 0] = 28
    vis_predict_object[foreground_labels[0], foreground_labels[1], 1] = 148
    vis_predict_object[foreground_labels[0], foreground_labels[1], 2] = 255
        
    return vis_predict_object

def main(): 
    parser = ArgumentParser()
    parser.add_argument("-p", "--model_checkpoint_path", dest="model_checkpoint_path", help="path to pytorch checkpoint file")
    parser.add_argument("-i", "--video_filepath", dest="video_filepath", help="path to input video")
    parser.add_argument("-o", "--output_file", dest="output_file", help="path to output video file")
    parser.add_argument('-v', "--vis", action='store_true', default=True, help="show frame by frame visualization")
    args = parser.parse_args() 

    # Load model
    model = DomainSegNetworkInfer(checkpoint_path=args.model_checkpoint_path)
    print('DomainSeg Model Loaded')
    
    cap = cv2.VideoCapture(args.video_filepath)
    if not cap.isOpened():
        print("Error opening video stream or file")
        return

    # Video writer
    output_filepath_obj = args.output_file + '.avi'
    fps = cap.get(cv2.CAP_PROP_FPS)
    writer_obj = cv2.VideoWriter(output_filepath_obj,
        cv2.VideoWriter_fourcc(*"MJPG"), fps, (1280,720))

    alpha = 0.5
    print('Processing started')

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print('Frame not read - ending processing')
            break

        # Convert frame for inference
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image_pil = Image.fromarray(image).resize((640, 320))
      
        # Run inference
        prediction = model.inference(image_pil)
        vis_obj = make_visualization(prediction)

        # Resize for output
        frame_hd = cv2.resize(frame, (1280, 720))
        vis_obj_hd = cv2.resize(vis_obj, (1280, 720))

        # Blend original frame with prediction
        image_vis_obj = cv2.addWeighted(vis_obj_hd, alpha, frame_hd, 1 - alpha, 0)

        # Save frame
        writer_obj.write(image_vis_obj)

        # Show live preview at 640x480
        if args.vis:
            preview = cv2.resize(image_vis_obj, (640, 480))
            cv2.imshow('DomainSeg Prediction', preview)
            # Press Q to stop preview
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    writer_obj.release()
    cv2.destroyAllWindows()
    print('Completed')

if __name__ == '__main__':
    main()
# %%

