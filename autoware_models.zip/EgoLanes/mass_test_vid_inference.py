import os
import subprocess
import sys
from tqdm import tqdm

BEST_WEIGHT_PATH = "/home/aiexnvidia24/weights/Autoware/EgoLanes/weights_egolanes.pth"
TEST_VID_DIR = "/home/aiexnvidia24/weights/videos/source/EgoLanes"
OUTPUT_VID_DIR = "/home/aiexnvidia24/weights/videos/output/EgoLanes"
if (not os.path.exists(OUTPUT_VID_DIR)):
    os.makedirs(OUTPUT_VID_DIR)

for vid_file in tqdm(
    sorted(os.listdir(TEST_VID_DIR)),
    colour = "green"
):
    if vid_file.endswith(".mp4"):
        
        vid_id = vid_file.split(".")[0]
        input_vid_path = os.path.join(TEST_VID_DIR, vid_file)
        output_vid_dir = os.path.join(OUTPUT_VID_DIR, vid_id + ".avi")

        command = [
            sys.executable,	
            #"uv", "run", "python3",
            "EgoLanes/video_visualization.py",
            "-i", input_vid_path,
            "-o", output_vid_dir,
            "-p", BEST_WEIGHT_PATH
        ]

        result = subprocess.run(
            command,
            check = True
        )
