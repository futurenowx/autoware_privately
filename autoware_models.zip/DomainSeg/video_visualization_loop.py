#%%
import cv2
import sys
import os
import time
import numpy as np
from PIL import Image
from argparse import ArgumentParser

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from inference.domain_seg_infer import DomainSegNetworkInfer

def make_visualization(prediction):
    row, col = prediction.shape
    vis_predict_object = np.zeros((row, col, 3), dtype=np.uint8)

    # Background color
    vis_predict_object[:, :, 0] = 255
    vis_predict_object[:, :, 1] = 93
    vis_predict_object[:, :, 2] = 61

    # Foreground mask
    fg = (prediction == 1.0)
    vis_predict_object[fg] = (28, 148, 255)
        
    return vis_predict_object

def main(): 
    parser = ArgumentParser()
    parser.add_argument("-p", "--model_checkpoint_path", required=True)
    parser.add_argument("-i", "--video_filepath", required=True)
    parser.add_argument("--skip_frames", type=int, default=0,
                        help="Number of frames to skip between processing")
    parser.add_argument("-s", "--show_scale", type=float, default=1.0,
                        help="Scale factor to downscale preview window")
    args = parser.parse_args() 

    # Load model
    model = DomainSegNetworkInfer(checkpoint_path=os.path.expanduser(args.model_checkpoint_path))
    print('DomainSeg Model Loaded')

    cap = cv2.VideoCapture(args.video_filepath)
    if not cap.isOpened():
        print("Error opening video stream or file")
        return

    alpha = 0.5
    prev_time = time.time()
    frame_count = 0
    total_frames = 0
    print('Processing started')

    while True:
        ret, frame = cap.read()
        if not ret:
            # Restart video from beginning
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        total_frames += 1
        if args.skip_frames > 0 and total_frames % (args.skip_frames + 1) != 0:
            continue

        # Resize once for model
        frame_small = cv2.resize(frame, (640, 320), interpolation=cv2.INTER_LINEAR)
        rgb_small = cv2.cvtColor(frame_small, cv2.COLOR_BGR2RGB)
        image_pil = Image.fromarray(rgb_small)

        # Run inference
        prediction = model.inference(image_pil)
        prediction = np.squeeze(prediction)
        if prediction.dtype != np.integer:
            prediction = (prediction + 0.5).astype(np.int32)

        # Visualization
        vis_obj = make_visualization(prediction)  # RGB
        vis_obj_bgr = cv2.cvtColor(vis_obj, cv2.COLOR_RGB2BGR)

        # Blend overlay
        blended = cv2.addWeighted(vis_obj_bgr, alpha, frame_small, 1 - alpha, 0)

        # Scale preview window
        if args.show_scale != 1.0:
            w = int(blended.shape[1] * args.show_scale)
            h = int(blended.shape[0] * args.show_scale)
            preview = cv2.resize(blended, (w, h), interpolation=cv2.INTER_LINEAR)
        else:
            preview = blended

        # FPS monitor
        frame_count += 1
        t = time.time()
        if t - prev_time >= 1.0:
            print(f"FPS: {frame_count}")
            frame_count = 0
            prev_time = t

        # Show
        cv2.imshow('DomainSeg Prediction', preview)

        if cv2.waitKey(1) & 0xFF in (ord('q'), ord('Q')):
            break

    cap.release()
    cv2.destroyAllWindows()
    print('Stopped')

if __name__ == '__main__':
    main()
# %%

