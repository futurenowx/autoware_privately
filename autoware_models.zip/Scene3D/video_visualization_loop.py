#%%
import cv2
import sys
import numpy as np
from PIL import Image
import os
import cmapy
from argparse import ArgumentParser

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from inference.scene_3d_infer import Scene3DNetworkInfer


def main(): 

    parser = ArgumentParser()
    parser.add_argument("-p", "--model_checkpoint_path", dest="model_checkpoint_path", required=True)
    parser.add_argument("-i", "--video_filepath", dest="video_filepath", required=True)
    parser.add_argument("--skip_frames", type=int, default=0,
                        help="Number of frames to skip between inferences (0 = no skipping)")
    parser.add_argument("-s", "--show_scale", type=float, default=1.0,
                        help="Scale factor for preview window")
    args = parser.parse_args() 

    # Load model
    model = Scene3DNetworkInfer(checkpoint_path=os.path.expanduser(args.model_checkpoint_path))
    print('Scene3D Model Loaded')
    
    # Open video input
    cap = cv2.VideoCapture(args.video_filepath)
    if not cap.isOpened():
        print("Error opening video stream or file")
        return

    print('Processing started')
    alpha = 0.97  # transparency factor
    frame_count = 0
    total_frames = 0

    last_prediction_vis = None  # store last visualized prediction for skipped frames

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        total_frames += 1

        # Skip frames if requested
        if args.skip_frames > 0 and total_frames % (args.skip_frames + 1) != 0:
            # Use last prediction visualization for display
            if last_prediction_vis is not None:
                preview = last_prediction_vis
            else:
                preview = cv2.resize(frame, (640, 480))
            if args.show_scale != 1.0:
                h, w = preview.shape[:2]
                preview = cv2.resize(preview, (int(w * args.show_scale), int(h * args.show_scale)))
            cv2.imshow("Scene3D Depth Visualization (Live)", preview)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            continue

        # Convert frame for model
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image_pil = Image.fromarray(image_rgb).resize((640, 320))

        # Run inference
        prediction = model.inference(image_pil)
        prediction = cv2.resize(prediction, (frame.shape[1], frame.shape[0]))

        # Normalize depth map
        prediction_image = 255.0 * (
            (prediction - np.min(prediction)) /
            (np.max(prediction) - np.min(prediction) + 1e-6)  # avoid div by zero
        )
        prediction_image = prediction_image.astype(np.uint8)

        # Apply colormap
        vis_obj = cv2.applyColorMap(prediction_image, cmapy.cmap('viridis'))

        # Blend with original frame
        frame_hd = cv2.resize(frame, (1280, 720))
        vis_obj_hd = cv2.resize(vis_obj, (1280, 720))
        image_vis_obj = cv2.addWeighted(vis_obj_hd, alpha, frame_hd, 1 - alpha, 0)

        # Show preview at 640x480 or scaled
        preview = cv2.resize(image_vis_obj, (640, 480))
        if args.show_scale != 1.0:
            h, w = preview.shape[:2]
            preview = cv2.resize(preview, (int(w * args.show_scale), int(h * args.show_scale)))

        last_prediction_vis = preview  # store for skipped frames
        cv2.imshow("Scene3D Depth Visualization (Live)", preview)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print('Stopped')


if __name__ == '__main__':
    main()
# %%

