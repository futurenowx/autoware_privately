# %%
# AutoSteer + EgoLanes Visualization (robust & portable)

import sys
import cv2
import json
import os
import numpy as np
from PIL import Image
from argparse import ArgumentParser
from datetime import datetime, timedelta

# -------------------------
# Imports
# -------------------------
sys.path.append('../..')
from Models.inference.auto_steer_infer import AutoSpeedNetworkInfer
from inference.ego_lanes_infer import EgoLanesNetworkInfer

# -------------------------
# Utilities
# -------------------------
def rotate_wheel(wheel_img, angle_deg):
    h, w = wheel_img.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle_deg, 1.0)
    return cv2.warpAffine(
        wheel_img, M, (w, h),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0, 0)
    )


def overlay_on_top(base_img, rotated_wheel_img, frame_time, steering_angle, rotated_gt_wheel_img=None):
    H, W = base_img.shape[:2]
    oh, ow = rotated_wheel_img.shape[:2]
    x = W - ow - 60
    y = 20

    image = base_img.copy()

    def alpha_blend(dst, src, x, y):
        alpha = src[:, :, 3] / 255.0
        for c in range(3):
            dst[y:y+src.shape[0], x:x+src.shape[1], c] = (
                src[:, :, c] * alpha +
                dst[y:y+src.shape[0], x:x+src.shape[1], c] * (1 - alpha)
            )

    alpha_blend(image, rotated_wheel_img, x, y)

    if rotated_gt_wheel_img is not None:
        alpha_blend(image, rotated_gt_wheel_img, x - 148, y)

    cv2.putText(image, frame_time, (x - 60, y + oh + 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    cv2.putText(image, f"{steering_angle:.2f} deg", (x - 60, y + oh + 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    return image


def load_ground_truth(gt_file_path):
    with open(gt_file_path, "r") as f:
        return json.load(f)


def overlay_egolanes(frame, lane_mask, threshold=0.3):
    overlay = frame.copy()
    H, W = frame.shape[:2]

    if lane_mask.ndim == 3:
        for i in range(lane_mask.shape[0]):
            lm = cv2.resize(lane_mask[i], (W, H), interpolation=cv2.INTER_NEAREST)
            mask = lm >= threshold
            colors = [(255, 0, 255), (255, 0, 0), (0, 255, 0), (255, 0, 255)]
            overlay[mask] = colors[i % len(colors)]
    else:
        lm = cv2.resize(lane_mask, (W, H), interpolation=cv2.INTER_NEAREST)
        overlay[lm >= threshold] = (0, 255, 0)

    return cv2.addWeighted(frame, 1.0, overlay, 0.5, 0)


# -------------------------
# Main
# -------------------------
def main():
    parser = ArgumentParser()
    parser.add_argument("-e", "--egolanes_checkpoint_path", required=True)
    parser.add_argument("-a", "--autosteer_checkpoint_path", required=True)
    parser.add_argument("-i", "--video_filepath", required=True)
    parser.add_argument("-o", "--output_file", required=True)
    parser.add_argument("-v", "--vis", action="store_true", default=False)
    parser.add_argument("-g", "--ground_truth")
    args = parser.parse_args()

    # -------------------------
    # Expand user paths
    # -------------------------
    args.video_filepath = os.path.expanduser(args.video_filepath)
    args.output_file = os.path.expanduser(args.output_file)
    args.egolanes_checkpoint_path = os.path.expanduser(args.egolanes_checkpoint_path)
    args.autosteer_checkpoint_path = os.path.expanduser(args.autosteer_checkpoint_path)
    if args.ground_truth:
        args.ground_truth = os.path.expanduser(args.ground_truth)

    # -------------------------
    # Load models
    # -------------------------
    autosteer_model = AutoSpeedNetworkInfer(
        egolanes_checkpoint_path=args.egolanes_checkpoint_path,
        autosteer_checkpoint_path=args.autosteer_checkpoint_path
    )
    egolanes_model = EgoLanesNetworkInfer(args.egolanes_checkpoint_path)
    print("Models loaded")

    # -------------------------
    # Video input
    # -------------------------
    cap = cv2.VideoCapture(args.video_filepath)
    if not cap.isOpened():
        raise RuntimeError(f"❌ Could not open video: {args.video_filepath}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        print("⚠️ FPS not detected, defaulting to 30")
        fps = 30

    # -------------------------
    # Output setup
    # -------------------------
    output_dir = os.path.dirname(args.output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    writer = cv2.VideoWriter(
        args.output_file + ".avi",
        cv2.VideoWriter_fourcc(*"MJPG"),
        fps,
        (1280, 720)
    )
    if not writer.isOpened():
        raise RuntimeError("❌ VideoWriter failed to open")

    # -------------------------
    # Load wheels (relative path)
    # -------------------------
    media_path = os.path.join(
        os.path.dirname(__file__),
        "../../../Media/wheel_green.png"
    )

    if not os.path.exists(media_path):
        raise FileNotFoundError(f"Wheel image not found: {media_path}")

    wheel = cv2.resize(cv2.imread(media_path, cv2.IMREAD_UNCHANGED), None, fx=0.8, fy=0.8)
    gt_wheel = wheel.copy()

    # -------------------------
    # Ground truth
    # -------------------------
    gt = load_ground_truth(args.ground_truth) if args.ground_truth else None
    start_datetime = datetime.now()
    frame_idx = 0

    # -------------------------
    # Processing loop
    # -------------------------
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb).resize((640, 320))

        steering_angle = autosteer_model.inference(pil)
        lane_mask = egolanes_model.inference(np.array(pil))

        frame = cv2.resize(frame, (1280, 720))
        frame = overlay_egolanes(frame, lane_mask)

        rotated_wheel = rotate_wheel(wheel, steering_angle)
        rotated_gt = None
        if gt:
            gt_angle = gt["frames"][frame_idx]["steering_angle_corrected"]
            rotated_gt = rotate_wheel(gt_wheel, gt_angle)

        timestamp = (start_datetime + timedelta(seconds=frame_idx / fps)).strftime("%m/%d/%Y %H:%M:%S")
        frame = overlay_on_top(frame, rotated_wheel, timestamp, steering_angle, rotated_gt)

        if args.vis:
            cv2.imshow("AutoSteer + EgoLanes", frame)
            cv2.waitKey(1)

        writer.write(frame)
        frame_idx += 1

    cap.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"✅ Completed. Output saved to {args.output_file}.avi")


if __name__ == "__main__":
    main()
# %%

